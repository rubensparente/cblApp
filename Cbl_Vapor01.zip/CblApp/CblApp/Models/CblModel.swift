//
//  CblModel.swift
//  CblApp
//
//  Created by Rubens Parente on 11/09/24.
//

import Foundation

class CblModel: ObservableObject{
    
    let httpCliente = HTTPClient()
    
    func register(username: String, password: String) async throws -> RegisterResponseDTO{
        
        let registerData = ["username": username, "password": password]
        let resource = try Resource(url: Constants.Urls.register, method: .post(JSONEncoder().encode(registerData)), modelType: RegisterResponseDTO.self)
        
        let registerResponseDTO = try await httpCliente.load(resource)
        
        return registerResponseDTO
    }
    
    func login(username: String, password: String) async throws -> LoginResponseDTO{
        
        let loginPostData = ["username": username, "password": password]
        
        //resource
        let resource = try Resource(url: Constants.Urls.login, method: .post(JSONEncoder().encode(loginPostData)), modelType: LoginResponseDTO.self)
        
        let loginResponseDTO = try await httpCliente.load(resource)
        
        if !loginResponseDTO.error && loginResponseDTO.token != nil && loginResponseDTO.userId != nil{
            //save the token in user defaults
            
            let defaults = UserDefaults.standard
            defaults.set(loginResponseDTO.token!, forKey: "authToken")
            defaults.set(loginResponseDTO.userId!.uuidString, forKey: "userId")
        }
        return loginResponseDTO
    }
}

