//
//  AppState.swift
//  CblApp
//
//  Created by Rubens Parente on 17/09/24.
//

import Foundation

enum Route: Hashable{
    case login
    case register
    case cblCategoryList
}


class AppState: ObservableObject{
    @Published var router: [Route] = []
}

