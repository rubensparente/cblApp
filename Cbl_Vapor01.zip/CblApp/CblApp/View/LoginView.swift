//
//  LoginView.swift
//  CblApp
//
//  Created by Rubens Parente on 12/09/24.
//

import SwiftUI

struct LoginView: View {
    
    @EnvironmentObject private var model: CblModel
    
    @State private var username: String = ""
    @State private var password: String = ""
    @State private var errorMessage: String = ""
    
    
    private var isFormValid: Bool{
        !username.isEmptyOrWhiteSpace && !password.isEmptyOrWhiteSpace
    }
    
    private func login() async{
        do{
            let loginResponseDTO = try await model.login(username: username, password: password)
            if loginResponseDTO.error{
                // take the user to cbl category list view
                errorMessage = loginResponseDTO.reason ?? ""
            }else{
                //take the user to Cbl categories list view
            }
        }catch{
            errorMessage = error.localizedDescription
        }
    }
    
    var body: some View {
        
        Form{
            TextField("Usuário", text: $username)
                .textInputAutocapitalization(.never)
            SecureField("Password", text: $password)
            
            HStack{
                Button("Login"){
                    Task{
                        await login()
                    }
                }.buttonStyle(.borderless)
                    .disabled(!isFormValid)
            }
            Text(errorMessage)
        }.navigationTitle("Login")
       
    }
}

#Preview {
    LoginView()
}
