//
//  CblAppApp.swift
//  CblApp
//
//  Created by Rubens Parente on 09/09/24.
//

import SwiftUI

@main
struct CblAppApp: App {

@StateObject private var model = CblModel()
    @StateObject private var appState = AppState()
    
    var body: some Scene {
        WindowGroup {
            NavigationStack{
                RegistrationView()
                    .navigationDestination(for: Route.self){ route in
                        switch route{
                        case .register:
                            RegistrationView()
                        case .login:
                            LoginView()
                        case .cblCategoryList:
                            Text("CBL Lista Categoria")
                        }
                        
                    }
            }.environment(model)
                .environment(appState)
        }
    }
}
