//
//  File.swift
//  
//
//  Created by Rubens Parente on 10/09/24.
//

import Foundation
import Fluent
import Vapor


final class User: Model, Content, Validatable{
    static let schema = "users"
    
    @ID(key: .id)
    var id: UUID?
    
    @Field(key: "username")
    var username: String
    @Field(key:"password")
    var password: String
    
    init(){ }
    
    init(id: UUID? = nil, username: String, password: String){
        self.id = id
        self.username = username
        self.password = password
    }
    
    static func validations(_ validations: inout Validations) {
        validations.add("username", as: String.self, is: !.empty, customFailureDescription: "Nome do usuário não pode ficar em branco.")
        validations.add("password", as: String.self, is: !.empty, customFailureDescription: "Senha não pode ficar em branco.")

        //Senha tem que ter entre 6 a 10 caracteres
        validations.add("password", as: String.self, is: .count(6...10), customFailureDescription: "Senha tem que ter entre 6 a 10 caracteres.")
    }
}
