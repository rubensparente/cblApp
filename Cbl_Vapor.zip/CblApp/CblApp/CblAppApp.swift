//
//  CblAppApp.swift
//  CblApp
//
//  Created by Rubens Parente on 09/09/24.
//

import SwiftUI

@main
struct CblAppApp: App {

@StateObject private var model = CblModel()
    
    var body: some Scene {
        WindowGroup {
            LoginView()
                .environmentObject(model)
        }
    }
}
