//
//  LoginResponseDTO.swift
//  CblApp
//
//  Created by Rubens Parente on 12/09/24.
//

import Foundation

struct LoginResponseDTO: Codable{
    
    let error: Bool
    var reason: String? = nil
    let token: String? = nil
    let userId: UUID? = nil
}
