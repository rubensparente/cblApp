//
//  RegisterResponseDTO.swift
//  CblApp
//
//  Created by Rubens Parente on 11/09/24.
//

import Foundation

struct RegisterResponseDTO: Codable{
    let error: Bool
    var reason: String? = nil
}
