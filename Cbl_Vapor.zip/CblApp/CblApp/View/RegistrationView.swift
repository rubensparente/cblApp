//
//  SwiftUIView.swift
//  CblApp
//
//  Created by Rubens Parente on 10/09/24.
//

import SwiftUI

struct RegistrationView: View {
    
    @EnvironmentObject private var model: CblModel
    
    @State private var username: String = ""
    @State private var password: String = ""
    
    @State private var errorMessage: String = ""
    
    private var isFormValid: Bool{
        !username.isEmptyOrWhiteSpace && !password.isEmptyOrWhiteSpace && ((password.count >= 6) && (password.count <= 10))
    }
    
    private func register() async{
       
        do{
          let registerResponseDTO =  try await model.register(username: username, password: password)
           
            if !registerResponseDTO.error{
                //Take the user to the login screen
            }else{
                errorMessage = registerResponseDTO.reason ?? ""
            }
        }catch{
            errorMessage = error.localizedDescription
        }
    }
    
    var body: some View {
        Form{
            TextField("Usuário", text: $username)
                .textInputAutocapitalization(.never)//Utilizado para não deixar a primeira letra em maiuscula
            SecureField("Senha", text: $password)
            
            HStack(){
                Button("Salvar"){
                    Task{
                        await register()
                    }
                }
                .buttonStyle(.borderless)
                .disabled(!isFormValid)
                
            }
        }
        .navigationTitle("Cadastrar Usuário")
    
    }
    
}

struct RegistrationView_Previews: PreviewProvider{
    static var previews: some View{
        NavigationStack{
            RegistrationView()
                .environmentObject(CblModel())
            
        }
    }
}

