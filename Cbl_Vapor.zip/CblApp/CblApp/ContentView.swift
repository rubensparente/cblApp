//
//  ContentView.swift
//  CblApp
//
//  Created by Rubens Parente on 09/09/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        
        
        Text("Teste")
    }
}
#Preview {
    ContentView()
}
